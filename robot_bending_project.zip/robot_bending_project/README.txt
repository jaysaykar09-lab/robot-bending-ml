Robot Bending ML Project

Steps:
1) pip install -r requirements.txt
2) cd backend
3) uvicorn app:app --reload
4) cd ../frontend
5) python -m http.server 5500
6) Open http://127.0.0.1:5500/index.html
